package Yuxiang.Crawler;
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.io.FileUtils;

public class Crawling implements Callable<Set<String>> {
	
	static Set<String> finished_links = new HashSet<String>();
	static Queue<String> queue = new LinkedList<String>();
	
	
	public Set<String> call() throws Exception {
		String nextlink = queue.poll();
		while(finished_links.contains(nextlink))
		{
			nextlink = queue.poll();
		}
		Set<String> Set_links = new HashSet<String>();
		String result = new String();
		result = read_site.read(nextlink);
		System.out.println(queue.size());
		read_site.write_txt(Thread.currentThread().getName() + finished_links.size(), result);
		//File file = new File("/home/yuxiang/Documents/page/"+k+".txt");
		System.out.println(Thread.currentThread().getName());
		Set_links.addAll(find_sites.extract(result, nextlink));
		queue.addAll(Set_links);
		finished_links.add(nextlink);
		return Set_links;
	}
	
	public static void main(String[] args) throws IOException, InterruptedException, ExecutionException{
		//String url = "http://nba.sports.sina.com.cn/match_result.php";
		//queue.addAll(FileUtils.readLines(new File("/home/yuxiang/Documents/record.txt"), "utf-8"));
		String url = "http://sports.sina.com.cn/";
		queue.add(url);
		String link = queue.poll();
		String result = read_site.read(link);
		queue.addAll(find_sites.extract(result, link));
		link = queue.poll();
		result = read_site.read(link);
		queue.addAll(find_sites.extract(result, link));
		FileWriter fw = new FileWriter (new File("/home/yuxiang/Documents/records.txt"));
		BufferedWriter bw = new BufferedWriter (fw);
		PrintWriter record = new PrintWriter (bw);
		ExecutorService executor = Executors.newFixedThreadPool(10);
        List<Future<Set<String>>> list = new ArrayList<Future<Set<String>>>();
        for(int i=0; i < 200; i++){
            Future<Set<String>> future = executor.submit(new Crawling());
    		list.add(future);
        }
        for(Future<Set<String>> fut : list){
        	fut.get();
        }
        System.out.println(queue.size());
		for(String i:finished_links){
			record.println(i + "\n");
		}
		record.close();
		executor.shutdown();
	}
	
}

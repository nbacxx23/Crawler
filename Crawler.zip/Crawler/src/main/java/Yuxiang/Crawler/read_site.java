package Yuxiang.Crawler;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.io.BufferedWriter;

public class read_site{
	public static String read(String url){
		String result = "";
		BufferedReader in = null;
		try
		{
			URL realUrl = new URL(url);
			URLConnection connection = realUrl.openConnection();
			connection.setReadTimeout(15*1000);
			connection.connect();
			in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			while ((line = in.readLine()) != null)
			{
				result += line + "\n";
			}
		}
		catch (IOException e) {
			e.printStackTrace();
			}
		
		return result;
	}
	public static void write_txt(String k, String result)
	{
		try{
			FileWriter fw = new FileWriter (new File("/home/yuxiang/Documents/page/"+k+".txt"));
			BufferedWriter bw = new BufferedWriter (fw);
			PrintWriter txt = new PrintWriter (bw);	
			txt.println(result);
			txt.close();
		}	
		catch (IOException e) {
			e.printStackTrace();
			}
	}
	public static void write_html(int k, String result)
	{
		try{
			FileWriter fw = new FileWriter (new File("/home/yuxiang/Documents/page/"+k+".html"));
			BufferedWriter bw = new BufferedWriter (fw);
			PrintWriter html = new PrintWriter (bw);	
			html.println(result);
			html.close();
		}	
		catch (IOException e) {
			e.printStackTrace();
			}
	}
	
}